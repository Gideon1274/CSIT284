package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class PassingIntentsExercise2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passing_intents_exercise2);

        Intent intent = getIntent();
        if (intent != null) {
            String fullName = intent.getStringExtra("fname_key") + " " + intent.getStringExtra("lname_key");
            String phoneNumber = intent.getStringExtra("pnum_key");
            String gender = intent.getStringExtra("gender_key");
            String emailAddress = intent.getStringExtra("eadd_key");
            String motherName = intent.getStringExtra("mother_key");
            String age = intent.getStringExtra("age_key");
            String address = intent.getStringExtra("address_key");
            String fatherName = intent.getStringExtra("father_key");
            String birthDate = intent.getStringExtra("bdate_key");
            
            TextView displayFullname = findViewById(R.id.displayFullname);
            TextView displayPhoneNumber = findViewById(R.id.displayPhoneNumber);
            TextView displayGender = findViewById(R.id.displayGender);
            TextView displayEmailAddress = findViewById(R.id.displayEmailAddress);
            TextView displayMother = findViewById(R.id.displayMother);
            TextView displayAge = findViewById(R.id.displayAge);
            TextView displayAddress = findViewById(R.id.displayAddress);
            TextView displayFather = findViewById(R.id.displayFather);
            TextView displayBirthdate = findViewById(R.id.displayBirthdate);

            displayFullname.setText(fullName);
            displayPhoneNumber.setText(phoneNumber);
            displayGender.setText(gender);
            displayEmailAddress.setText(emailAddress);
            displayMother.setText(motherName);
            displayAge.setText(age);
            displayAddress.setText(address);
            displayFather.setText(fatherName);
            displayBirthdate.setText(birthDate);

        }
    }
}