package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Arrays;

public class MidtermExam extends AppCompatActivity {
    boolean gameActive = true;
    int activePlayer = 0;
    int[] gameState = {2, 2, 2, 2, 2, 2, 2, 2, 2};
    int[][] winPositions ={{0, 1, 2}, {3, 4, 5}, {6, 7, 8},{0, 3, 6}, {1, 4, 7}, {2, 5, 8},{0, 4, 8}, {2, 4, 6}};
    public static int counter = 0;
    public void playerTap(View view) {
        ImageView img =(ImageView) view;
        int tappedImage = Integer.parseInt(img.getTag().toString());
        if (gameActive == false) {
            resetGame(view);
            return;
        }
        if (gameState[tappedImage] == 2) {
            counter++;
            if (counter == 9) {
                gameActive = false;
            }
            gameState[tappedImage] = activePlayer;
            updateCell(img);
            switchPlayer();
            updateStatus();
            checkGameState();
        }
    }
    private void updateCell(ImageView img) {
        img.setTranslationY(-1000f);
        LinearLayout layout = findViewById(R.id.wholeLayout);
        if(activePlayer == 0){
            layout.setBackgroundColor(-999999);
            img.setImageResource(R.drawable.x);
        }
        else{
            layout.setBackgroundColor(999999999);
            img.setImageResource(R.drawable.o);
        }

        img.animate().translationYBy(1000f).setDuration(300);
    }
    private void switchPlayer() {
        activePlayer = (activePlayer == 0) ? 1 : 0;
    }
    private void updateStatus() {
        TextView status = findViewById(R.id.textView);
        String playerSymbol;
        if(activePlayer == 0){
            playerSymbol = "X";
        }
        else{
            playerSymbol = "O";
        }
        status.setText(playerSymbol+"'s turn");
    }

    private void checkGameState() {
        if (counter > 4) {
            for (int[] winPosition : winPositions) {
                if (gameState[winPosition[0]] == gameState[winPosition[1]] &&gameState[winPosition[1]] == gameState[winPosition[2]] &&gameState[winPosition[0]] != 2) {
                    endGame(winPosition);
                    return;
                }
            }
            if (counter == 9) {
                TextView status = findViewById(R.id.textView);
                status.setText("Match Draw");
                gameActive = false;
            }
        }
    }

    private void endGame(int[] winPosition) {
        String winnerStr = (gameState[winPosition[0]] == 0) ? "X has won" : "O has won";
        TextView status = findViewById(R.id.textView);
        status.setText(winnerStr);
        gameActive = false;
    }

    public void resetGame(View view) {
        gameActive = true;
        activePlayer = 0;
        Arrays.fill(gameState, 2);
        resetImageViews();
        updateStatus();
        counter = 0;
    }

    private void resetImageViews() {
        for (int i = 0;i < 8;i++) {
            int resId = getResources().getIdentifier("imageView" + i, "id", getPackageName());
            ImageView img = findViewById(resId);
            img.setImageResource(0);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        updateStatus();
    }

}