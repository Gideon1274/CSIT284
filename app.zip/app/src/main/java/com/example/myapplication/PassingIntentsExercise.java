package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class PassingIntentsExercise extends AppCompatActivity {

    EditText eFName, eLName, eBDate, eNum, eMail, eAge, eFatherName, eMotherName, eAddress;
    RadioButton rMale, rFem, rOther;
    Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passing_intents_exercise);

        // Initialize EditText and RadioButtons
        eFName = findViewById(R.id.edittextFirstName);
        eLName = findViewById(R.id.edittextLastname);
        eBDate = findViewById(R.id.editBirthDate);
        eNum = findViewById(R.id.editPhoneNumber);
        eMail = findViewById(R.id.editEmailAddress);
        eAge = findViewById(R.id.editAge);
        eFatherName = findViewById(R.id.editFatherName);
        eMotherName = findViewById(R.id.editMotherName);
        eAddress = findViewById(R.id.editAddress);


        btnSubmit = findViewById(R.id.btnSubmit);

        rMale = findViewById(R.id.radiobuttonMale);
        rFem = findViewById(R.id.radiobuttonFemale);
        rOther = findViewById(R.id.radiobuttonOthers);

        // Set OnClickListener for btnSubmit
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String fName = eFName.getText().toString();
                String lName = eLName.getText().toString();
                String bDate = eBDate.getText().toString();
                String pNumber = eNum.getText().toString();
                String emailAdd = eMail.getText().toString();
                String age = eAge.getText().toString();
                String father = eFatherName.getText().toString();
                String mother = eMotherName.getText().toString();
                String address = eAddress.getText().toString();

                String gender;

                if(rMale.isChecked()){
                    gender = "Male";
                } else if(rFem.isChecked()){
                    gender = "Female";
                } else if(rOther.isChecked()){
                    gender = "Others";
                } else {
                    gender = "Unknown";
                }

                Intent intent = new Intent(PassingIntentsExercise.this, PassingIntentsExercise2.class);
                intent.putExtra("fname_key", fName);
                intent.putExtra("lname_key", lName);
                intent.putExtra("gender_key", gender);
                intent.putExtra("bdate_key", bDate);
                intent.putExtra("pnum_key", pNumber);
                intent.putExtra("eadd_key", emailAdd);
                intent.putExtra("age_key", age);
                intent.putExtra("father_key", father);
                intent.putExtra("mother_key", mother);
                intent.putExtra("address_key", address);

                startActivity(intent);
            }
        });
    }

    public void clearText(View view) {
        EditText editText = (EditText) view;
        editText.setText("");
    }

    public void onClick(View v){
        String fName = eFName.getText().toString();
        String lName = eLName.getText().toString();
        String bDate = eBDate.getText().toString();
        String pNumber = eNum.getText().toString();
        String emailAdd = eMail.getText().toString();

        String gender;
        if(rMale.isChecked()){
            gender = "Male";
        } else if(rFem.isChecked()){
            gender = "Female";
        } else if(rOther.isChecked()){
            gender = "Others";
        } else {
            gender = "Unknown";
        }

        String age = eAge.getText().toString();
        String father = eFatherName.getText().toString();
        String mother = eMotherName.getText().toString();
        String address = eAddress.getText().toString();

        Intent intent = new Intent(PassingIntentsExercise.this, PassingIntentsExercise2.class);
        intent.putExtra("fname_key", fName);
        intent.putExtra("lname_key", lName);
        intent.putExtra("gender_key", gender);
        intent.putExtra("bdate_key", bDate);
        intent.putExtra("pnum_key", pNumber);
        intent.putExtra("eadd_key", emailAdd);
        intent.putExtra("age_key", age);
        intent.putExtra("father_key", father);
        intent.putExtra("mother_key", mother);
        intent.putExtra("address_key", address);
        startActivity(intent);
    }
    public void clearAllFields(View view) {
        eFName.setText("First Name");
        eLName.setText("Last Name");
        eBDate.setText("");
        eNum.setText("");
        eMail.setText("");
        eFatherName.setText("");
        eMotherName.setText("");
        eAddress.setText("");
        eAge.setText("");


        // Clear RadioGroup selection
        rMale.setChecked(false);
        rFem.setChecked(false);
        rOther.setChecked(false);
    }
}
