package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import com.example.myapplication.MainActivity;
import android.widget.Toast;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.view.ViewGroup;
import android.graphics.Color;
import android.content.res.Resources;

import java.util.Random;

public class Buttons extends AppCompatActivity {

    Button button5, button6,button7,button8,button9;
    private int backgroundColor;
    private boolean button6Visibility;
    private boolean button7Background;

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("backgroundColor", backgroundColor);
        outState.putBoolean("button6Visibility", button6Visibility);
        outState.putBoolean("button7Background", button7Background);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buttons);

        button5 = findViewById(R.id.button5);
        button6 = findViewById(R.id.button6);
        button7 = findViewById(R.id.button7);
        button8 = findViewById(R.id.button8);
        button9 = findViewById(R.id.button9);

        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Random random = new Random();
                int red = random.nextInt(256);
                int green = random.nextInt(256);
                int blue = random.nextInt(256);
                getWindow().getDecorView().setBackgroundColor(Color.rgb(red, green, blue));
            }
        });

        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button button = (Button) v;
                button.setVisibility(View.GONE);
            }
        });

        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Random random = new Random();
                int red = random.nextInt(256);
                int green = random.nextInt(256);
                int blue = random.nextInt(256);
                button7.setBackgroundColor(Color.rgb(red, green, blue));
            }
        });
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(
                        Buttons.this,
                        AnotherActivity.class);

                startActivity(intent1);
            }
        });
        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Buttons.this, "Manko Suki", Toast.LENGTH_SHORT).show();
            }
        });

    }
}