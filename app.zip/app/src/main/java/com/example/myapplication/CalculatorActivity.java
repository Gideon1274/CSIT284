package com.example.myapplication;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Stack;

public class CalculatorActivity extends AppCompatActivity {
    ArrayList<Button> numbers = new ArrayList<>();
    ArrayList<Button> operations = new ArrayList<>();
    Calculate calculator = new Calculate();
    boolean hasDot = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);
        calculator();
    }

    public void calculator(){
        Button clearBtn =  (Button) findViewById(R.id.buttonClear);
        Button equalBtn =  (Button) findViewById(R.id.button33);
        Button pointBtn =  (Button) findViewById(R.id.button31);
        TextView resultText =  (TextView) findViewById(R.id.answerDisplay);
        TextView expressionText =  (TextView) findViewById(R.id.display);

        numbers.add( (Button) findViewById(R.id.button32));
        numbers.add( (Button) findViewById(R.id.button28));
        numbers.add( (Button) findViewById(R.id.button29));
        numbers.add( (Button) findViewById(R.id.button37));
        numbers.add( (Button) findViewById(R.id.button34));
        numbers.add( (Button) findViewById(R.id.button22));
        numbers.add( (Button) findViewById(R.id.button24));
        numbers.add( (Button) findViewById(R.id.button25));
        numbers.add( (Button) findViewById(R.id.button36));
        numbers.add( (Button) findViewById(R.id.button26));

        operations.add((Button) findViewById(R.id.button35));
        operations.add((Button) findViewById(R.id.button30));
        operations.add((Button) findViewById(R.id.button23));
        operations.add((Button) findViewById(R.id.button27));

        for(int i = 0; i < numbers.size(); i++){
            numbers.get(i).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Button b = (Button) view;
                    String buttonText = b.getText().toString();
                    String currentExpression = expressionText.getText().toString();

                    if(currentExpression.isEmpty() || "+-*/".contains(currentExpression.substring(currentExpression.length() - 1))) {
                        if (buttonText.equals("-")) {
                            expressionText.append(buttonText);
                        }
                    }

                    expressionText.append(buttonText);

                    try{
                        float result = calculator.calculate(expressionText.getText().toString(), false);
                        if(result == (int) result){
                            resultText.setText(String.valueOf((int)result));
                        }else{
                            resultText.setText(Float.toString(result));
                        }
                    }catch (Exception e){
                        resultText.setText(e.getMessage());
                    }
                }
            });
        }


        pointBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Button b = (Button) view;
                String buttonText = b.getText().toString();
                String current = expressionText.getText().toString();

                if (current.length() > 0) {
                    char last = current.charAt(current.length() - 1);
                    if (last == '.') {
                        expressionText.setText(current.substring(0, current.length() - 1));
                        hasDot = false;
                    } else if (hasDot == true) {
                        return;
                    }else{
                        expressionText.append(buttonText);
                        hasDot = true;
                    }
                } else {
                    expressionText.append(buttonText);
                    hasDot = true;
                }
            }
        });

        for(int i = 0; i < operations.size(); i++){
            operations.get(i).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    hasDot = false;
                    Button b = (Button) view;
                    String buttonText = b.getText().toString();
                    String current = expressionText.getText().toString();
                    if(current.equals("")) return;
                    Character last = current.charAt(current.length() - 1);

                    if(last == '+' || last == '-' || last == '*' || last == '/' || last == '%'){
                        current = current.substring(0, current.length() - 1) + buttonText;
                        expressionText.setText(current);
                    }else{
                        expressionText.append(buttonText);
                    }
                }
            });
        }
        equalBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String expression = expressionText.getText() + "";
                hasDot = false;
                try {
                    float result = calculator.calculate(expression, false); // Set sequential to false
                    if(result == (int) result){
                        resultText.setText(String.valueOf((int)result));
                        return;
                    }
                    resultText.setText(Float.toString(result));
                } catch (Exception e) {
                    resultText.setText(e.getMessage());
                }
            }
        });
        clearBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hasDot = false;
                expressionText.setText("");
                resultText.setText("0");
            }
        });
    }
}